create database biblioteca;
use biblioteca;

create table editora(
id int not null,
nome_editora varchar(100),
cnpj char(14),
endereco varchar (45),
fone varchar(45),
cidade varchar (45),
estado char (2),
 constraint primary key (id)

);
show tables;
drop table livro;
create table livro(
id_livro varchar(45),
titulo varchar(45),
ISBN char (10),
pagina INT,
idioma varchar (45),
data_publicacao DATE,
id_editora INT,
id_autor INT,
constraint primary key (id_livro)
);
select* from livro;
create table autor(
id_autor int not null auto_increment,
cpf char(11),
nome varchar (45),
email varchar(45),
telefone char(11),
constraint primary key (id_autor)
);

insert into editora(id,nome_editora)
values(190756,'Suma');
insert into editora(id,nome_editora)
values(343459,'‎ Galera');
insert into editora(id,nome_editora)
values(025396,'Companhia das Letras');
insert into editora(id,nome_editora)
values(740157,' Pottermore Publishing');
select * from livro ;

insert into livro(id_livro,titulo,ISBN,pagina,idioma,data_publicacao,id_editora,id_autor)
values(19033,'It a coisa',27252735,210,'ingles',21/10,1020,1913);
insert into livro(id_livro,titulo,ISBN,pagina,idioma,data_publicacao,id_editora,id_autor)
values(13234,'É assim que acaba',9821-9130,200,'alemao',20/02,5676,1235);
insert into livro(id_livro,titulo,ISBN,pagina,idioma,data_publicacao,id_editora,id_autor)
values(43443,'A revoluçao dos bichos',9369-0925,134,'ingles',17/09,0998,9203);
insert into livro(id_livro,titulo,ISBN,pagina,idioma,data_publicacao,id_editora,id_autor)
values(32393,'Harry Potter',2333-9763,210,'ingles',01/02,7172,7821);

insert into autor(id_autor,nome)
values(1913,'Stephen King');
insert into autor(id_autor,nome)
values(1235,'Collen Hoover');
insert into autor(id_autor,nome)
values(9203,'George orwell');
insert into autor(id_autor,nome)
values(7821,'JK rowling');
select * from autor;

select editora.nome_editora,livro.titulo
from editora
inner join livro
on editora.id = livro.id_livro;
select * from editora;
