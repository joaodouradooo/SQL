create database eventos;
use eventos;

create table  cadastro(
id_cadastro int not null auto_increment,
nome varchar (100) not null,
fone char (11),
id_palestra int,
constraint primary key(id_cadastro)
);

insert into cadastro (id_cadastro,nome,fone,id_palestra)
values(default,"joao","67992335981",1);

insert into cadastro (id_cadastro,nome,fone,id_palestra)
values(default,"miguel","190",2);

insert into cadastro (id_cadastro,nome,fone,id_palestra)
values(default,"paulo","191",3);


drop table cadastro;


select * from cadastro;

select * from palestra;


create table palestra(
id int auto_increment not null,
nome varchar (100) not null,
vagas int,
constraint primary key (id)
);
insert into palestra (id,nome,vagas)
values(default,"Game designer",15);

insert into palestra (id,nome,vagas)
values(default,"After effects",11);

insert into palestra (id,nome,vagas)
values(default,"Linux",8)

DELIMITER %%
CREATE TRIGGER tr_atualiza_vagas after insert on cadastro
for each row
BEGIN 
update palestra
set vagas=vagas-1
where id= new.id_palestra;
END
%%
drop trigger tr_atualiza_vagas;

