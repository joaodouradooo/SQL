create database cadastro;
use cadastro;

show tables;
show databases;
create table pessoa(	
	id int not null,
    nome varchar(100) not null,
    idade int not null,
	telefone char(11),
    endereco varchar(150),
    constraint primary key(id)
);

describe pessoa;

insert into pessoa(id,nome,idade,telefone,endereco)
values (10,"joao",12,"190","rua da imprensa");

insert into pessoa(id,nome,idade,telefone,endereco)
values (144,"ana",15,"191","rua pipoca");

insert into pessoa(id,nome,idade,telefone,endereco)
values (56,"cr7",09,"6778-2733","rua da carai");

insert into pessoa(id,nome,idade,telefone,endereco)
values (32,"messi",66,"6233-5910","rua do olho");

insert into pessoa(id,nome,idade,telefone,endereco)
values (43,"patrick",21,"6799-0921","rua da maejoana");

insert into pessoa(id,nome,idade,telefone,endereco)
values (87,"bob",33,"6897-8293","fenda do bikini");

select * FROM pessoa;


select * from pessoa order by nome asc;
update pessoa set nome ="neymar" where id=43;
select * from pessoa where idade =10 or nome like "%m";
select nome from pessoa where id in (10,43);
select avg(idade) as media from pessoa;
select sum(idade) as soma from pessoa;
select sum(idade) as soma from pessoa;
select count(*)as contador, sum(idade) as soma,avg(idade)
as media from pessoa;

select max(idade) from pessoa;
select min(idade) from pessoa;

alter table pessoa add column cidade varchar(100);
select * from pessoa;
update pessoa set cidade= "Campo grande" where id >10;
update pessoa set cidade="RJ" where id=10;
update pessoa set cidade="BUENOS AIRES" where id=32;
update pessoa set cidade="SAO PAULO" where id=43;
select distinct(cidade) from pessoa;
update pessoa set cidade="NOVA JERUSALEM" where id=56;
select count(id),cidade from pessoa