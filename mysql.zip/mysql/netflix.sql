create database netflixx;

use netflixx;

show tables;

create table usuarioss(
	id_usuario int not null auto_increment,
    cpf char(11),
    nome varchar (100),
    email varchar (100),
    senha varchar (100),
    
    constraint primary key (id_usuario)
    
);
drop table usuarioss;

create table playy(
	id_play int not null auto_increment,
    _data date,
    usuarios_id int,
    series_id int,
    
    constraint primary key (id_play)
    
);
drop table playy;
create table seriess(
	id_series int not null auto_increment,
    nome varchar (100),
    sinopse varchar (100),
    temporadas smallint,
    
    constraint primary key (id_series)
  );  
  show tables;
insert into usuarioss(cpf,nome,email,senha)
values('486.698.734-00','nina','nina1908@gmail','nininha123');

insert into usuarioss(cpf,nome,email,senha)
values('928.555.544-62','marcio','marcio123@gmail','macus123');

insert into usuarioss(cpf,nome,email,senha)
values('928.513.451-34','helena','helena1223@gmail','helencatioro');

insert into usuarioss(cpf,nome,email,senha)	
values('642.241.544-13','alessandra','alessandrabla@gmail','mycat122');

insert into usuarioss(cpf,nome,email,senha)
values('134.098.231-76','joao','joaod@gmail','jvdiuu123');

insert into usuarioss(cpf,nome,email,senha)
values('676.453.235-43','alex','machao123@gmail','goiaba14');

insert into usuarioss(cpf,nome,email,senha)
values('177.981.523-44','nats','natggmai@gmail','lazarento222');

insert into usuarioss(cpf,nome,email,senha)
values('123.777.244-44','lua','lua190@gmail','acetona455');


insert into seriess(nome,sinopse,temporadas)
values('jeff dahmer','um jovem canibal doido',1);
insert into seriess(nome,sinopse,temporadas)
values('peaky blinders','mafiosos de boina',6);
insert into seriess(nome,sinopse,temporadas)
values('CupHead','xicaras que fazem pacto com o capeta',2);
insert into seriess(nome,sinopse,temporadas)
values('vikings','vikings fazendo guerra',7);
insert into seriess(nome,sinopse,temporadas)
values('you','um sociopata que gosta muito de muie',4);

insert into playy(_data,usuarios_id,series_id)
values(11/1221





select * from usuarioss;