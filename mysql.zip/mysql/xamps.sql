create database dgt;
use dgt;


show tables;
create table cargo


select * from cargo;
update cargo set in_dep = 7 where id_cargo = 1;
insert into cargo values (default," vendedor",1);
describe funcionario;
select * from funcionario;
update funcionario set
data_admissao=current_date(),
cidade ="Campo grande",
nacionalidade = "brasileiro" where id_func >3;


create table pessoa(
id int not null,
cpf char (11) not null,
endereco varchar(110),
telefone char (11),
constraint primary key(id));

insert into pessoa
select id_func,cpf, endereco,telefone from funcionario;


select * from pessoa;


update funcionario set nome = "Marina" where id_funf > 1;
select id_funf from funcionario where nome like 'J%';

insert into funcionario
(cpf,nome,salario,endereco,telefone,data_nasc,id_dep,id_cargo)
values("123","joao",19,999,"rua Tal,293","321","9999-2321")





delete from funcionario
where id_funf
in (2,3);