create database cad_ex;
use cad_ex;
show tables;

create table Funcionario(

	id int not null,
    nome varchar(45) not null,
    idade int,
    salario varchar(7),
    cpf char(15),
    endereco varchar(50),
    telefone varchar(15),
    DataNascimento varchar(45),
    cidade varchar(45),
    nacionalidade varchar(45),
    DataAdm varchar(45),
    
    
    constraint primary key (id)
);

insert into Funcionario (id,nome,idade,cpf,endereco,telefone,cidade,nacionalidade,DataNascimento,DataAdm,salario)
values (1,'Diego Santos Silva',19,'016.189.751-70','Rua Metropoli','(67) 99352-2608','Campo grande','Brasileiro','05/12/2002','10/03/2019','7.000');
insert into Funcionario (id,nome,idade,cpf,endereco,telefone,cidade,nacionalidade,DataNascimento,DataAdm,salario)
values (2,'Nathan Pizolito',19,'515.000.541-00','Rua manoel gome','(67) 2977-8661','Sao paulo','Brasileiro','05/09/2003','10/02/2020','1.500');
insert into Funcionario (id,nome,idade,cpf,endereco,telefone,cidade,nacionalidade,DataNascimento,DataAdm,salario)
values (3,'Marina sophia','17','424.292.501-87','Rua Tiririca','(67) 97663-7672','Sao Paulo','Brasileiro','13/06/2005',06/12/2020,'3.000');
insert into Funcionario (id,nome,idade,cpf,endereco,telefone,cidade,nacionalidade,DataNascimento,DataAdm,salario)
values (4,'João Vitor',19,'610.162.771-30','Rua Arlindo lima','(67) 99146-5109','Costa Rica','Brasileiro','19/07/2003','18/07/2016','2.500');
insert into Funcionario (id,nome,idade,cpf,endereco,telefone,cidade,nacionalidade,DataNascimento,DataAdm,salario)
values (5,'Thiago Sandre',17,'371.399.871-06','Rua Flamengo','(67) 97438-7452','Campo grande','Brasileiro','06/06/2005','25/01/2020','2.000');
insert into Funcionario (id,nome,idade,cpf,endereco,telefone,cidade,nacionalidade,DataNascimento,DataAdm,salario)
values (6,'Luan victor',18,'567.754.101-07','Eiler de azevedo','(67) 97573-8522','Sao Paulo','Brasileiro','06/05/2004','26/08/2021','3.500');
insert into Funcionario (id,nome,idade,cpf,endereco,telefone,cidade,nacionalidade,DataNascimento,DataAdm,salario)
values (7,'Julia Ajpert',18,'804.086.640-53','Rua das Garças','(67) 99286-1543','Costa Rica','Brasileiro','15/10/2004','18/09/2020','4.000');
insert into Funcionario (id,nome,idade,cpf,endereco,telefone,cidade,nacionalidade,DataNascimento,DataAdm,salario)
values (9,'Surle Martins',44,'825.571.281-04','Rua Monte de andrade','(67) 97510-8651','Campo Grande','Brasileiro','16/03/1972','02/11/1992','2.200');
insert into Funcionario (id,nome,idade,cpf,endereco,telefone,cidade,nacionalidade,DataNascimento,DataAdm,salario)
values (10,'José Fernandes',35,'935.932.820-03','Zahran do norte','(67) 97439-6875','Costa Rica','Brasileiro','06/05/1987','15/04/2006','1.400');
insert into Funcionario (id,nome,idade,cpf,endereco,telefone,cidade,nacionalidade,DataNascimento,DataAdm,salario)
values (11,'Nathan Henrique',25,'442.622.601-51','Rua Nortao','(67) 97432-3272','Sao paulo','Brasileiro','06/05/1997','25/05/2010','3.200');
insert into Funcionario (id,nome,idade,cpf,endereco,telefone,cidade,nacionalidade,DataNascimento,DataAdm,salario)
values (12,'Erik Silva',30,'781.297.354-90','Rua jaci Vieira','(67) 99468-1358','Campo grande','Brasileiro','06/05/1992','16/08/2007','1.900');
select * from Funcionario;
create table Departamento(
	id int not null,
    nomeDepartamento varchar (45),
    
    constraint primary key (id)
);

insert into Departamento(id,nomeDepartamento)
values (10,'RH');
insert into Departamento(id,nomeDepartamento)
values (20,'Arquivo');
insert into Departamento(id,nomeDepartamento)
values (30,'Almoxarifado');
insert into Departamento(id,nomeDepartamento)
values (40,'Copa');
insert into Departamento(id,nomeDepartamento)
values (50,'Protocolo');

select * from Departamento;

create table Dependentes(
	id int not null,
    nome varchar (45),
    datanascimento varchar (45),
	localnascimento varchar(45),
    idempregado varchar (45),
    numerocertidao varchar (45),
   
    constraint primary key (id)
);

insert into Dependentes(id,nome,datanascimento,localnascimento,idempregado,numerocertidao)
values('1','Yago Otávio Ramos','01/03/2011','Campo Grande','1','17620');
insert into Dependentes(id,nome,datanascimento,localnascimento,idempregado,numerocertidao)
values('2','Kevin Renan Oliveira','30/03/2018','São Paulo','11','67908');
insert into Dependentes(id,nome,datanascimento,localnascimento,idempregado,numerocertidao)
values('3','Leandro Kauê Pietro Nascimento','08/03/2015','Costa Rica','10','76127');
insert into Dependentes(id,nome,datanascimento,localnascimento,idempregado,numerocertidao)
values('4','Thomas Julio Galvão','18/08/2012','Sao Paulo','12','49508');
insert into Dependentes(id,nome,datanascimento,localnascimento,idempregado,numerocertidao)
values('5','Carlos Eduardo Cauã Jesus','07/04/2002','Campo Grande','9','45233');
insert into Dependentes(id,nome,datanascimento,localnascimento,idempregado,numerocertidao)
values('6','César Benjamin Osvaldo Corte Real','23/04/2022','Campo Grande','3','01018');

select * from  dependentes;


create table Cargos(
	id int not null,
    NomeCargo varchar (45),
    idDepartamento varchar (45),
    nomeDepartamento varchar (45),
    
    constraint primary key (id)
);
drop table Cargos;

insert into Cargos (id,NomeCargo,idDepartamento,nomeDepartamento)
values (1,'Psicologo','20','RH');
insert into Cargos (id,NomeCargo,idDepartamento,nomeDepartamento)
values (2,'Auxiliar Economico','10','Arquivo');
insert into Cargos (id,NomeCargo,idDepartamento,nomeDepartamento)
values (3,'Desenvolvedor Junior','30','Almoxarifado');
insert into Cargos (id,NomeCargo,idDepartamento,nomeDepartamento)
values (4,'Pedreiro','40','Copa');
insert into Cargos (id,NomeCargo,idDepartamento,nomeDepartamento)
values (5,'Atendente','50','Protocolo');

select * from Cargos;

select * from dependentes;

update Funcionario set salario ="6500" where id=3;

update  Funcionario set endereco="AV afonso Pena,5432" where id <5;

select nome, idade from Funcionario order by idade desc;

select * from Funcionario order by idade desc;

select * from funcionario where id >8 and id <18;

select * from funcionario where id in (1,2,8,18,21);


select nome,salario from funcionario where nome like 'j%';


select nome,salario from funcionario where nome like '%a';

select count(*) as contador from funcionario;


select min(salario) as menor from funcionario;


select max(idade) as maior from funcionario;


select avg(salario) as media from funcionario;


select count(id) as contador from funcionario where idade = 19;






