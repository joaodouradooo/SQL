create database empresa;
use empresa;
create table funcionario(
	id int not null auto_increment,
    nome varchar(100) not null,
    data_nasc date not null,
    admissao datetime,
    constraint primary key (id)
    );
    
alter table funcionario add column cadastro timestamp;
describe funcionario;

insert into funcionario(nome,data_nasc,admissao)
values ('joao',curdate(),current_date());

insert into funcionario(nome,data_nasc,admissao)
values ('joao','2003-07-19',current_date());

select * from funcionario;

SELECT nome,date_format(data_nasc,'%d/%m/a%')as date from funcionario;

SELECT nome,data_nasc,date_add(data_nasc,interval 2 year)
from funcionario;

SELECT current_timestamp() as MOMENTO;
select nome,year(data_nasc) from funcionario where nome like "1%";

select timestampdiff(year,data_nasc,now()) from funcionario;